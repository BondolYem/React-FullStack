//step1
const {course , PI , objPerson, getGradeByAvg} = require('./src/data/product')
const {students} = require('./src/data/students_obj')

//  let average = 99.99
//  let myGrade = getGradeByAvg(average)   // call function 

//  console.log("My grade: " + myGrade)

 
// for(let i = 0; i < students.length; i++){
//     console.log(students[i].name)
// }

// students.forEach((student, index) => {
//     console.log(`Student ${index}: ${student.name}`);
// });
 

for(stu of students){
    console.log(stu)
}