
const course = [
    "C++",
    "Java",
    "C#"
];
const PI = 2003.14;
const objPerson = {
    Id : 101,
    Name : "Dara",
    Gender : "male"
}

function getGradeByAvg(average){
    var grade = "";// A B C
    if(average >= 90 && average <= 100){
        grade = "A";
    }else if(average >= 80 && average < 90){
        grade = "B";
    }else if(average >= 70 && average < 80){
        grade = "C";
    }else if(average >= 60 && average < 70){
        grade = "D";
    }else if(average >= 50 && average < 60){
        grade = "E";
    }else if(average >= 0 && average < 50){
        grade = "F";
    }
    return grade;
}

module.exports = {
    course , PI, objPerson, getGradeByAvg
}