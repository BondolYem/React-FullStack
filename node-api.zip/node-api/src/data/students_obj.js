
const students = [
    { name: 'John', age: 20, grade: 'A', sex: 'M'},
    { name: 'Alice', age: 22, grade: 'B', sex: 'M'},
    { name: 'Bob', age: 21, grade: 'C' , sex: 'F'}
  ];

module.exports = {students};