const Config = {
  // ACCESS_TOKEN_KEY: "#@$!%$^$4595969932fdfddfklfkfdlffEWEWEWdfgs3243434",
  // REFRESH_TOKEN_KEY: "dkfdjffdkhdkf#@$!%$^$4595969932fdfkrgkfdljdfde"

  ACCESS_TOKEN_KEY: "#@$!%$^$4595969932fd;kkdbre;k;fkrgk';fEWEWEWdfgs3243434",
  REFRESH_TOKEN_KEY: "#4345435345FDSLEK@($I$*%*^&#sjfa;lkj;lrqkjlkkk2323232323"
};

module.exports = {
  Config,
};
