const { Config } = require("../config/config");
const db = require("../config/db");
const { logError, isEmptyOrNull } = require("../config/service");

const getList = async (req, res) => {
  try {
    // FOR LOCAL
    var sql =
      "SELECT c.* , ct.Name as CategoryName from course c inner join category ct on c.CategoryId = ct.Id";
    var sql_cat = "SELECT * from category";
    const [list] = await db.query(sql);
    const [category] = await db.query(sql_cat);

    res.json({
      list: list,
      category: category,
    });
  } catch (error) {
    logError("Course.getList", error, res);
  }
};

const create = async (req, res) => {
  try {
    var {
      CategoryId,
      Name,
      Description,
      Image,
      TotalHour,
      Price,
      IsActive,
      CreateBy,
      CreateAt,
    } = req.body;
    var error = {};

    if (isEmptyOrNull(CategoryId)) {
      error.CategoryId = "CategoryId required!";
    }
    if (isEmptyOrNull(Name)) {
      error.Name = "Name required!";
    }
    if (Object.keys(error).length > 0) {
      res.json({
        error: error,
      });
      return false;
    }
    var parameter = {
      CategoryId: CategoryId,
      Name: Name,
      Description: Description,
      Image: Image,
      TotalHour: TotalHour,
      Price: Price,
      IsActive: IsActive,
      CreateBy: CreateBy,
      CreateAt: CreateAt,
    };
    const [courses] = await db.query(
      "INSERT INTO Course (CategoryId, Name, Description, Image, TotalHour, Price, IsActive, CreateBy, CreateAt) VALUES (:CategoryId, :Name, :Description, :Image, :TotalHour, :Price, :IsActive, :CreateBy, :CreateAt)",
      parameter
    );

    res.json({
      message: "Created Successfully!",
      list: courses,
    });
  } catch (error) {
    logError("Courses.create", error, res);
  }
};
const update = async (req, res) => {
  try {
    var {
      Id,
      CategoryId,
      Name,
      Description,
      Image,
      TotalHour,
      Price,
      IsActive,
      CreateBy,
      CreateAt,
    } = req.body;
    var error = {};

    if (isEmptyOrNull(Id)) {
      error.Id = "Id required!";
    }
    if (isEmptyOrNull(Name)) {
      error.Name = "Name required!";
    }

    if (Object.keys(error).length > 0) {
      res.json({
        error: error,
      });
      return false;
    }
    var parameter = {
      Id: Id,
      CategoryId: CategoryId,
      Name: Name,
      Description: Description,
      Image: Image,
      TotalHour: TotalHour,
      Price: Price,
      IsActive: IsActive,
      CreateBy: CreateBy,
      CreateAt: CreateAt,
    };
    const [course] = await db.query(
      "UPDATE Course SET CategoryId=:CategoryId, Name=:Name, Description=:Description, Image=:Image,TotalHour=:TotalHour, Price=:Price,IsActive=:IsActive WHERE Id=:Id",
      parameter
    );
    res.json({
      message: "Updated Successfully!",
      list: course,
    });
  } catch (error) {
    logError("Course.update", error, res);
  }
};
const remove = async (req, res) => {
  try {
    var Id = req.params.id;
    var error = {};
    if (isEmptyOrNull(Id)) {
      error.Id = "Id required!";
    }
    if (Object.keys(error).length > 0) {
      res.json({
        error: error,
      });
      return false;
    }
    var parameter = {
      Id: Id,
    };
    const [list] = await db.query("DELETE FROM Course WHERE Id=:Id", parameter);
    res.json({
      list: list,
    });
  } catch (error) {
    logError("course.remove", error, res);
  }
};
module.exports = {
  getList,
  create,
  update,
  remove,
};
