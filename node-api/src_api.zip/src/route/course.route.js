const {
    getList,
    create,
    update,
    remove,
} = require("../controller/course.controller")
const course = (app) => {
    app.get("/api/course",getList);
    app.post("/api/course",create);
    app.put("/api/course",update);
    app.delete("/api/course/:id",remove);
}
module.exports = {
    course
}